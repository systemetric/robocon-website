#  _   _  _  _  _
# | | | |(_)| || | ___
# | |_| || || || |/ __|
# |  _  || || || |\__ \
# |_| |_||_||_||_||___/
#  ____                    _
# |  _ \  ___    __ _   __| |
# | |_) |/ _ \  / _` | / _` |
# |  _ <| (_) || (_| || (_| |
# |_| \_\\___/  \__,_| \__,_|
#  ____         _              ____
# |  _ \  ___  | |__    ___   / ___| ___   _ __
# | |_) |/ _ \ | '_ \  / _ \ | |    / _ \ | '_ \
# |  _ <| (_) || |_) || (_) || |___| (_) || | | |
# |_| \_\\___/ |_.__/  \___/  \____|\___/ |_| |_|
#  ____   ___  _  ___  
# |___ \ / _ \/ |/ _ \ 
#   __) | | | | | (_) |
#  / __/| |_| | |\__, |
# |_____|\___/|_|  /_/ 
#                      
# Hello, intrepid source-reader! If you're a RoboCon competitor, we
# *strongly* suggest that you don't modify the software on your brain
# box, including writing your own update! There are many things to
# consider that you may not have realised (for example, this update
# fixes an issue where your code -- including the updater -- would be
# randomly killed if other code had previously run without a reboot),
# and you're liable to stop your brain box from working properly if you
# get it wrong. If that happens, you'd need to send it back to us, which
# is a waste of everyone's time.
#
# In addition, this updater is not guaranteed to work properly if you've
# modified your brain box, and in any case it's likely to overwrite any
# changes you might have made. If you've made changes, but would still
# like to apply the update, contact us and we'll work something out.
#
# Also, in case you've forgotten, the disclaimer you signed with us
# at the beginning of the competition prohibits modifying our software,
# so yeah...
#
# Good luck with the competition!

############################################
# Patch #2                                 #
############################################

import os
import sys
import shutil
import time
import robot

robot.Robot()

print "Patching..."

rc_local = "/etc/rc.local"
lines = []

with open(rc_local) as f:
    line = " "
    while line != "":
        line = f.readline()
        lines.append(line)

if lines[1] != "# patch version: 2\n":
    print "Patching rc.local..."

    lines.insert(1, "# patch version: 2\n")

    mount_index = lines.index("mount --all\n")
    patch_script = [
        "",
        "PATCH_ZIP_PATH=\"/root/patch.zip\"",
        "if [ -e $PATCH_ZIP_PATH ] ; then",
        "    unzip -o $PATCH_ZIP_PATH -d /",
        "    rm -f $PATCH_ZIP_PATH",
        "    reboot",
        "fi"
    ]
    patch_script.reverse()
    for line in patch_script:
        lines.insert(mount_index + 1, line + "\n")

    with open(rc_local, "w") as f:
        f.writelines(lines)
else:
    print "Already patched rc.local"

print "Copying patch..."
dir_name = os.path.dirname(__file__)
patch_file = os.path.join(dir_name, "patch.zip")
patch_target = "/root/patch.zip"
shutil.copyfile(patch_file, patch_target)

print "Rebooting..."
time.sleep(3)
os.system("reboot")
